print("Hello, Bandit!")
